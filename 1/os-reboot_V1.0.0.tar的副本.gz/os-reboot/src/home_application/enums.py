# -*- coding: utf-8 -*-


class RUN_TYPE:
    def __init__(self):
        pass

    NOW = 'NOW'
    TIMER = 'TIMER'

class TASK_STATUS_TYPE:
    def __init__(self):
        pass

    WAITING = 'WAITING'
    RUNNING = 'RUNNING'
    DONE = 'DONE'
    FAIL = "FAIL"